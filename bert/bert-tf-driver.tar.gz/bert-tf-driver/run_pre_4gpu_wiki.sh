#       --init_checkpoint=$BERT_BASE_DIR/bert_model.ckpt \
python3 run_pretraining_multi_gpu.py \
       --input_file=/bert-data/*.tfrecord \
       --output_dir=/tmp/pretraining_output \
       --do_train=True \
       --do_eval=True \
       --bert_config_file=/root/msra_bert/bert/large/bert_config.json \
       --train_batch_size=4 \
       --eval_batch_size=4 \
       --max_seq_length=512 \
       --max_predictions_per_seq=20 \
       --num_train_steps=100000 \
       --num_warmup_steps=10 \
       --learning_rate=2e-5 \
       --n_gpus=4 |& tee bert-large-perf.log

rm -rf /tmp/pretraining_output 
