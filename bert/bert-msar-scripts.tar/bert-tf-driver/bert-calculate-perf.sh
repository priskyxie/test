#!/bin/bash
echo "global_steps per second is: "
cat $1 | grep 'py:692' | sed -e 's/.*://' | tail -n +3 |  awk '{ total += $1; count++ } END { print total/count }'  
echo "Batch sizes * global_steps/sec converts to examples/sec"
