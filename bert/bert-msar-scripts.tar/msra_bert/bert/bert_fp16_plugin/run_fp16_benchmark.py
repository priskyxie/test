#!/usr/bin/env python3

import os, sys, warnings, time
import tensorflow as tf
import numpy as np

from modeling_fp16_test import BertConfig, BertModel


batch_size, seq_len, nclass = 64, 128, 1024
if 'BATCH_SIZE' in os.environ:
  batch_size = int(os.environ['BATCH_SIZE'])
if 'SEQ_LEN' in os.environ:
  seq_len = int(os.environ['SEQ_LEN'])

batch_size = 4
seq_len = 512

print('Batch size for BERT =', batch_size)
print('Seq len for BERT =', seq_len)

bert_config = BertConfig(
      vocab_size=30522,
      hidden_size=1024,
      num_hidden_layers=24,
      num_attention_heads=16,
      intermediate_size=4096,
      type_vocab_size=2)

input_ids = tf.ones((batch_size, seq_len), dtype=tf.int32)
input_mask = tf.ones((batch_size, seq_len), dtype=tf.int32)
segment_ids = tf.ones((batch_size, seq_len), dtype=tf.int32)
labels = tf.ones((batch_size, ), dtype=tf.int32)

model = BertModel(
      config=bert_config,
      is_training=False,
      input_ids=input_ids,
      input_mask=input_mask,
      token_type_ids=segment_ids,
      use_one_hot_embeddings=False)

output_layer = model.get_pooled_output()
logits = tf.layers.dense(output_layer, units=nclass, activation=tf.nn.softmax)
loss = tf.losses.sparse_softmax_cross_entropy(logits=logits, labels=labels)
variables = tf.trainable_variables()

opt = tf.train.GradientDescentOptimizer(learning_rate=1e-4)
grads = opt.compute_gradients(loss)
train_op = opt.apply_gradients(grads)

config=tf.ConfigProto()
config.gpu_options.allow_growth=True
with tf.Session(config=config) as sess:
  sess.run(tf.global_variables_initializer())

  sess.run(train_op)
  num_step = 50
  tStart = time.time()
  for i in range(num_step):
    sess.run(train_op)
  tStop = time.time()

print('Done, average perf = %g samples/sec' % (batch_size * num_step / (tStop - tStart)))
