#!/bin/bash

curl -L https://github.com/ghostplant/public/releases/download/firewall/wiki.tfrecord -o $(dirname $0)/data/wiki-128.0.tfrecord
