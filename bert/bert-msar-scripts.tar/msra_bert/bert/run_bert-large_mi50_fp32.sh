#!/bin/bash


cd `dirname $0`

#SEQ=${S:-128}
#BAT=${B:-8}
SEQ=128
BAT=4

#INPUT_FILE=$(pwd)/data/wiki-${SEQ}.0.tfrecord
INPUT_FILE=/bert/bert/data/tf_examples.tfrecord

OUTPUT_DIR=/tmp/base
MAX_PRED=$((80 * ${SEQ} / 512))

echo "SEQ_LEN=${SEQ}, BATCH_SIZE=${BAT}, MAX_PRED=${MAX_PRED}"
sleep 1s

rm -rf ${OUTPUT_DIR}
mkdir ${OUTPUT_DIR}

python3 bert/run_pretraining.py --do_train \
                                                 --max_seq_length=${SEQ} \
                                                 --output_dir=${OUTPUT_DIR} \
                                                 --train_batch_size=${BAT} \
                                                 --bert_config_file=large/bert_config.json \
                                                 --input_file=${INPUT_FILE} \
                                                 --max_predictions_per_seq=${MAX_PRED} --single_gpu=False \
                                                 --num_train_steps=10

